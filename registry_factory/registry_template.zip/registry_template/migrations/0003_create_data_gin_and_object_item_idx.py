import django.contrib.postgres.indexes
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('{{ app_name }}', '0002_alter_object_item'),
    ]

    operations = [
        migrations.AddIndex(
            model_name='{{ model_name }}'.lower(),
            index=django.contrib.postgres.indexes.GinIndex(fields=['data'], name='{{ app_name }}_data_gin'),
        ),
        migrations.AddIndex(
            model_name='{{ model_name }}'.lower(),
            index=models.Index(fields=['object_item'], name='{{ app_name }}_object_item_idx'),
        ),
    ]
