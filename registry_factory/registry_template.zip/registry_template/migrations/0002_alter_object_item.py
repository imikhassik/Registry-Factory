from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('{{ app_name }}', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='{{ model_name }}'.lower(),
            name='object_item',
            field=models.UUIDField(default=None, null=True),
        ),
    ]
